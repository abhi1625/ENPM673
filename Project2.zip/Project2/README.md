# ENPM673
Projects for course Perception for Autonomous Robots
 
##Project 2: Lane Detection
Copy and extract the zip file in the desired location. Make sure the data files are in the `data` folder as present in the zip file.

- To run the code for the project video, type the following commands in the terminal:
```
python Lane_detection.py --video=project
```
-While for the challenge_video, run:
```
python Lane_detection.py --video=challenge
```
